USE PyDemo;
GO


IF EXISTS(SELECT * FROM sys.procedures WHERE name = 'uspChargeSummary_ChargeStatistics')
	DROP PROCEDURE report.uspChargeSummary_ChargeStatistics;
GO


CREATE PROCEDURE report.uspChargeSummary_ChargeStatistics
(
	@PracticeName				VARCHAR(20),
	@DepartmentName				VARCHAR(20),
	@ProviderKey				INT
)
AS
BEGIN

	DECLARE
		@StatisticsStartDate		DATE,
		@StatisticsStartDateKey		INT,
		@StatisticsEndDate			DATE,
		@StatisticsEndDateKey		INT;


	SET @StatisticsStartDate = DATEADD(dd, -180, CAST(SYSDATETIME() AS DATE));
	SET @StatisticsEndDate = DATEADD(dd, -1, CAST(SYSDATETIME() AS DATE));

	SET @StatisticsStartDateKey = dbo.ufnCalendarDateKey(@StatisticsStartDate);
	SET @StatisticsEndDateKey = dbo.ufnCalendarDateKey(@StatisticsEndDate);


	WITH Summary
	(
		CalendarKey,
		TotalCharges
	)
	AS
	(
		SELECT
			Chg.ChargePostingDateKey,
			TotalCharges = CAST(SUM(Chg.ChargeAmount) AS FLOAT)
		FROM
			fact.Charges Chg
				INNER JOIN
			dim.Department Dept
				On Chg.DepartmentKey = Dept.DepartmentKey
				INNER JOIN
			dim.ProcedureCode Prc
				On Chg.ProcedureCodeKey = Prc.ProcedureCodeKey
				INNER JOIN
			dim.Provider Prov
				On Chg.ProviderKey = Prov.ProviderKey
		WHERE
			(@PracticeName = '<All Practices>'
				OR
				Dept.Practice = @PracticeName)
			AND
			(@DepartmentName = '<All Departments>'
				OR
				Dept.Department = @DepartmentName)
			AND
			(@ProviderKey = -1
				OR
				Chg.ProviderKey = @ProviderKey)
			AND
			Chg.ChargePostingDateKey BETWEEN @StatisticsStartDateKey AND @StatisticsEndDateKey
		GROUP BY
			Chg.ChargePostingDateKey
	)
	SELECT
		Cal.CalendarDate,
		TotalCharges = ISNULL(Summ.TotalCharges, 0)
	INTO
		#Charges
	FROM
		dim.Calendar Cal
			LEFT JOIN
		Summary Summ
			ON Cal.CalendarKey = Summ.CalendarKey
	WHERE
		Cal.CalendarKey BETWEEN @StatisticsStartDateKey AND @StatisticsEndDateKey;


	DECLARE
		@InputQuery		NVARCHAR(500),
		@PyScript		NVARCHAR(500);

	SET @InputQuery = N'
	SELECT
		CalendarDate,
		TotalCharges
	FROM
		#Charges
	WHERE
		TotalCharges > 0
		AND
		DATEPART(dw, CalendarDate) BETWEEN 2 AND 6;';


	SET @PyScript = N'
import numpy as np
import pandas as pd

data = [np.mean(myQuery),
		np.std(myQuery),
		np.mean(myQuery) + 2 * np.std(myQuery),
		np.mean(myQuery) - 2 * np.std(myQuery)]
Results = pd.DataFrame(data)
Results = Results.T
	';

	EXEC sp_execute_external_script
		@language			= N'Python',
		@script				= @PyScript,
		@input_data_1		= @InputQuery,
		@input_data_1_name	= N'myQuery',
		@output_data_1_name	= N'Results'
	WITH RESULT SETS
	((
		"Mean"				NUMERIC(16, 4) NOT NULL,
		"StandardDeviation"	NUMERIC(16, 4) NOT NULL,
		"PlusTwoSigma"		NUMERIC(16, 4) NOT NULL,
		"MinusTwoSigma"		NUMERIC(16, 4) NOT NULL
	));

		DROP TABLE #Charges;

END;

GO


